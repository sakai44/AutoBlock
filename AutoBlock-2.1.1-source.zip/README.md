# AutoBlock 2.1.1 for MeowTils 2.0.1 / Minecraft 1.8.9

AutoBlock 2.1.1 offers Predict and Timed modes. Predict is the former Cycle
mode from AutoBlock 2.0.1, based on AutoBlock 1.0.7. The OpenJade swing-evidence
mode has been removed. The existing mode selector and mode-specific settings
layout remain.

Both modes require a sword and a living target established by an actual attack.
The target must remain under the crosshair, alive, in the current world, and
within Range. Check Left Click, Check Right Click, and Check Took Damage are
shared settings. Enabled checks combine with AND; disabling all three leaves
the target and range rules in place. Check Took Damage uses the local player's
resistance timer (`field_70172_ad > 0`) in both modes.

## Predict

Predict retains the 1.0.7 hurt-time cycle. Damage or an eligible attack arms
one block opportunity. Maximum hurt time sets the vulnerable start window;
Maximum hold duration limits the subsequent block. A zero hold duration
prevents starting a block. The 1.0.8 one-tick overlap is not included.

Defaults: Check Left Click on, Check Right Click off, Check Took Damage off,
Range 3.5 blocks, Maximum hurt time 4 ticks, Maximum hold duration 150 ms.
The former Prevent delaying attacks option and its behavior are removed.

## Timed

Timed starts blocking as soon as the target and selected checks pass. It holds
for Block duration, releases, waits for Time between blocks, then repeats while
the checks continue to pass. The two sliders are independent, each ranging
from 0 to 500 ms in 10 ms steps. Defaults request 100 ms held and 400 ms between
blocks. A zero block duration starts no blocks; a zero gap permits another
start on the next client input pass after release.

Timed measures elapsed client time using `System.nanoTime()`. Client tick PRE
queues one normal use-key press. Vanilla processes attacks before that press;
the right-click callback permits vanilla's use action and starts the hold timer.
Tick POST verifies that sword use actually began, handling cancelled interactions
without claiming a block. Render and client updates detect the hold deadline and
clear the synthetic use key. Vanilla's next using-item input branch sends release
and drains queued attack/use presses. Physical RMB is restored afterward, and the
gap timer begins only after the release is observed. Render callbacks do not send
normal Timed start/release packets, and held RMB cannot bypass an active gap.

Slider values are requested milliseconds. Applying transitions through input
passes can extend the actual hold/gap until the next client tick (normally about
50 ms between ticks, longer during stalls). Timed uses no packet buffering or
packet listeners. Check Took Damage can stop or restart its cycle.

## Key ownership and saved settings

The extension owns only the synthetic use-key press it starts and restores the
physical key state after vanilla releases it. Predict retains its existing
release path. Timed uses vanilla input for ordinary starts and timer/condition
releases. Exceptional teardown (disable, world change, invalid GUI/focus context)
retains the existing direct cleanup path and is not covered by the ordinary-cycle
ordering guarantee.
Switching modes, changing world/player context, or disabling the extension
cleans up an owned block and resets both cycles.

Previously saved `Cycle` mode values select Predict. Saved OpenJade Predict
settings are unused. A previously saved `Predict` selection also selects the
new Predict mode. The legacy millisecond hurt-time setting still migrates to
Maximum hurt time at 50 ms per tick.

## Build

Run `gradlew.bat timedRegression jar` with JDK 17, Gradle 8.8 and a writable
`GRADLE_USER_HOME`. Delivered bytecode targets Java 8. The artifact is
`build/libs/AutoBlock-2.1.1.meowtils`. Compile stubs, regression tests and MeowTils are not
packaged. Place the artifact in the MeowTils extensions directory and reload
or restart MeowTils. The ten simulated input-order scenarios cover ordered
start/release, actual-start timing, actual-release gap timing, zero gaps/holds,
target/condition loss, held RMB, cancelled use and pending-start cleanup. Actual
server packet traces and Grim flags still require in-game validation.
