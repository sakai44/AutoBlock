package meowtils.extension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.LongSupplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import org.lwjgl.input.Mouse;
import wtf.tatp.meowtils.event.AttackEntityEvent;
import wtf.tatp.meowtils.event.ClientTickEvent;
import wtf.tatp.meowtils.event.MouseInputEvent;
import wtf.tatp.meowtils.event.RenderTickEvent;

/** Exercises the production module against the 1.8.9 input branch ordering. */
public final class TimedInputRegressionTest {
    public static void main(String[] args) {
        orderedStartAndRelease();
        holdStartsAtInputAndGapStartsAtRelease();
        zeroGapWaitsForAnotherInputPass();
        zeroHoldDoesNotQueue();
        lostTargetCancelsOnlySyntheticPress();
        failedConditionUsesVanillaRelease();
        heldRightClickCannotShortenGap();
        cancelledUseDoesNotBecomeOwned();
        modeChangeCancelsQueuedStart();
        disableCancelsQueuedStart();
        System.out.println("Timed input regression: 10 scenarios passed");
    }

    private static void orderedStartAndRelease() {
        Fixture f = new Fixture();
        f.render();
        f.pre();
        f.render();
        check(f.controller.useCalls == 0, "Render and tick PRE must not send use");
        f.useTick(true, false);
        check(f.packets.equals(Arrays.asList("attack", "use", "movement")),
            "Start must follow queued attack and precede movement");
        f.advance(100);
        f.render();
        check(f.controller.releaseCalls == 0 && f.player.func_71039_bw(),
            "Deadline must preserve item use until vanilla handles release");
        f.pre();
        f.useTick(true, false);
        check(f.packets.equals(Arrays.asList("attack", "use", "movement", "release", "movement")),
            "Release branch must drain the queued attack before movement");
    }

    private static void holdStartsAtInputAndGapStartsAtRelease() {
        Fixture f = new Fixture();
        f.module.timeBetweenBlocks = 100;
        f.pre();
        f.advance(80);
        f.render();
        f.useTick(false, false);
        f.advance(99);
        f.render();
        check(f.use().func_151470_d(), "Queueing delay must not consume hold duration");
        f.advance(1);
        f.render();
        check(!f.use().func_151470_d(), "Deadline requests vanilla release");
        f.advance(80);
        f.pre();
        f.useTick(false, false);
        f.advance(99);
        f.pre();
        check(!f.use().func_151468_f(), "Gap must start at actual release");
        f.advance(1);
        f.pre();
        f.useTick(false, false);
        check(f.controller.useCalls == 2, "Restart after the complete gap");
    }

    private static void zeroGapWaitsForAnotherInputPass() {
        Fixture f = new Fixture();
        f.module.timeBetweenBlocks = 0;
        f.pre();
        f.useTick(false, false);
        f.advance(100);
        for (int i = 0; i < 20; ++i) f.render();
        check(f.controller.releaseCalls == 0 && f.controller.useCalls == 1,
            "Render callbacks cannot release/restart at zero gap");
        f.pre();
        f.useTick(false, false);
        for (int i = 0; i < 20; ++i) f.render();
        check(f.controller.useCalls == 1, "No render-time restart after release");
        f.pre();
        f.useTick(true, false);
        check(f.packets.equals(Arrays.asList("use", "movement", "release", "movement",
            "attack", "use", "movement")), "Movement separates release and restart");
    }

    private static void zeroHoldDoesNotQueue() {
        Fixture f = new Fixture();
        f.module.timedBlockDuration = 0;
        f.pre();
        f.render();
        check(!f.use().func_151468_f() && f.controller.useCalls == 0, "Zero hold starts nothing");
    }

    private static void lostTargetCancelsOnlySyntheticPress() {
        Fixture f = new Fixture();
        f.use().setQueuedPresses(2);
        f.pre();
        f.mc.field_71476_x.field_72308_g = null;
        f.render();
        check(f.use().drainQueuedPresses() == 2, "Cancel must preserve existing user presses");
        check(!f.use().func_151470_d() && f.controller.useCalls == 0, "Lost target clears pending start");
    }

    private static void failedConditionUsesVanillaRelease() {
        Fixture f = new Fixture();
        f.module.checkTookDamage = true;
        f.player.field_70172_ad = 1;
        f.pre();
        f.useTick(false, false);
        f.player.field_70172_ad = 0;
        f.render();
        check(f.controller.releaseCalls == 0, "Condition failure cannot send render-time release");
        f.pre();
        f.useTick(true, false);
        check(f.packets.equals(Arrays.asList("use", "movement", "release", "movement")),
            "Condition release must also drain queued attacks");
    }

    private static void heldRightClickCannotShortenGap() {
        Fixture f = new Fixture();
        Mouse.setButtonDown(1, true);
        f.module.checkRightClick = true;
        f.module.timeBetweenBlocks = 100;
        f.pre();
        f.useTick(false, false);
        f.advance(100);
        f.render();
        f.pre();
        f.useTick(true, false);
        check(f.use().func_151470_d(), "Restore physical RMB after vanilla releases");
        MouseInputEvent manual = new MouseInputEvent(MouseInputEvent.Action.RIGHT_CLICK);
        f.module.onMouseInput(manual);
        check(manual.isCancelled(), "Held RMB must not bypass Timed gap");
        f.advance(100);
        f.pre();
        f.useTick(false, false);
        check(f.controller.useCalls == 2, "Held RMB allows the next scheduled block");
        Mouse.setButtonDown(1, false);
    }

    private static void cancelledUseDoesNotBecomeOwned() {
        Fixture f = new Fixture();
        f.pre();
        f.useTick(false, true);
        check(!f.player.func_71039_bw() && !f.use().func_151470_d(), "Cancelled use restores key");
        f.advance(100);
        f.render();
        check(f.controller.releaseCalls == 0, "Do not release a block that never started");
        f.pre();
        f.useTick(false, false);
        check(f.controller.useCalls == 1, "Can retry after another listener cancels use");
    }

    private static void modeChangeCancelsQueuedStart() {
        Fixture f = new Fixture();
        f.pre();
        f.module.mode = "Predict";
        f.render();
        check(!f.use().func_151468_f() && !f.use().func_151470_d(), "Mode change removes pending use");
    }

    private static void disableCancelsQueuedStart() {
        Fixture f = new Fixture();
        f.pre();
        f.module.enabled = false;
        f.module.onDisable();
        check(!f.use().func_151468_f() && !f.use().func_151470_d(), "Disable removes pending use");
    }

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    private static final class Clock implements LongSupplier {
        long now = 1000000000L;
        public long getAsLong() { return now; }
    }

    private static final class Fixture {
        final Clock clock = new Clock();
        final Minecraft mc = Minecraft.func_71410_x();
        final EntityPlayerSP player = new EntityPlayerSP();
        final EntityLivingBase target = new EntityLivingBase();
        final List<String> packets = new ArrayList<String>();
        final Controller controller;
        final AutoBlock module;
        boolean input;

        Fixture() {
            Mouse.setButtonDown(0, true);
            Mouse.setButtonDown(1, false);
            mc.field_71474_y.field_74312_F.setQueuedPresses(0);
            use().setQueuedPresses(0);
            use().setDown(false);
            mc.field_71415_G = true;
            mc.field_71462_r = null;
            player.field_71071_by = new InventoryPlayer();
            player.field_71071_by.setStackInSlot(0, new ItemStack(new ItemSword()));
            target.setEntityId(25);
            target.setBoundingBox(new AxisAlignedBB(3, 0, -0.3, 3.6, 1.8, 0.3));
            mc.field_71439_g = player;
            mc.field_71441_e = new WorldClient() {
                public Entity func_73045_a(int id) { return id == 25 ? target : null; }
            };
            controller = new Controller(this);
            mc.field_71442_b = controller;
            mc.field_71476_x = new MovingObjectPosition();
            mc.field_71476_x.field_72313_a = MovingObjectPosition.MovingObjectType.ENTITY;
            mc.field_71476_x.field_72308_g = target;
            module = new AutoBlock(clock);
            module.mode = "Timed";
            module.enabled = true;
            module.onEnable();
            module.onAttackEntity(new AttackEntityEvent(player, target));
        }

        KeyBinding use() { return mc.field_71474_y.field_74313_G; }
        void advance(long millis) { clock.now += millis * 1000000L; }
        void pre() { module.onClientTick(new ClientTickEvent(ClientTickEvent.Phase.PRE)); }
        void render() { module.onRenderTick(new RenderTickEvent(RenderTickEvent.Phase.PRE, 0.0F)); }

        void useTick(boolean attack, boolean cancelUse) {
            mc.field_71474_y.field_74312_F.setQueuedPresses(attack ? 1 : 0);
            input = true;
            // Match Minecraft.runTick: choosing this branch happens BEFORE release.
            if (player.func_71039_bw()) {
                if (!use().func_151470_d()) controller.func_78766_c(player);
                mc.field_71474_y.field_74312_F.drainQueuedPresses();
                use().drainQueuedPresses();
            } else {
                if (mc.field_71474_y.field_74312_F.drainQueuedPresses() > 0) packets.add("attack");
                while (use().func_151468_f()) {
                    MouseInputEvent event = new MouseInputEvent(MouseInputEvent.Action.RIGHT_CLICK);
                    module.onMouseInput(event);
                    if (!event.isCancelled() && !cancelUse) {
                        controller.func_78769_a(player, mc.field_71441_e, player.func_70694_bm());
                    }
                }
            }
            input = false;
            packets.add("movement");
            module.onClientTick(new ClientTickEvent(ClientTickEvent.Phase.POST));
        }
    }

    private static final class Controller extends PlayerControllerMP {
        final Fixture fixture;
        Controller(Fixture fixture) { super(fixture.mc); this.fixture = fixture; }
        public boolean func_78769_a(EntityPlayer player, World world, ItemStack stack) {
            check(fixture.input, "Use sent outside vanilla input");
            fixture.packets.add("use");
            return super.func_78769_a(player, world, stack);
        }
        public void func_78766_c(EntityPlayer player) {
            check(fixture.input, "Release sent outside vanilla input");
            fixture.packets.add("release");
            super.func_78766_c(player);
        }
    }
}
