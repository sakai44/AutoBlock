package org.lwjgl.input;

public final class Keyboard {
    private static final boolean[] down = new boolean[256];

    private Keyboard() {
    }

    public static boolean isKeyDown(int code) {
        return code >= 0 && code < down.length && down[code];
    }

    public static void setKeyDown(int code, boolean value) {
        down[code] = value;
    }
}
