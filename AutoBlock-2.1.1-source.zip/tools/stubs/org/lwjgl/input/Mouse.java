package org.lwjgl.input;

public final class Mouse {
    private static final boolean[] down = new boolean[16];

    private Mouse() {
    }

    public static boolean isButtonDown(int button) {
        return button >= 0 && button < down.length && down[button];
    }

    public static void setButtonDown(int button, boolean value) {
        down[button] = value;
    }
}
