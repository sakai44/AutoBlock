package net.minecraft.world;

import net.minecraft.entity.Entity;

public class World {
    public Entity func_73045_a(int entityId) {
        return null;
    }
}
