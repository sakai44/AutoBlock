package net.minecraft.potion;

public class PotionEffect {
    private final int amplifier;

    public PotionEffect(int amplifier) {
        this.amplifier = amplifier;
    }

    public int func_76458_c() {
        return this.amplifier;
    }
}
