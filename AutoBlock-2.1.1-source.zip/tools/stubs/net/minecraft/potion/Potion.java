package net.minecraft.potion;

public class Potion {
    public static final Potion field_76430_j = new Potion();
    public static final Potion field_76429_m = new Potion();
}
