package net.minecraft.client.network;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.network.Packet;

public class NetHandlerPlayClient {
    public final List<Packet<?>> sentPackets = new ArrayList<Packet<?>>();
    public NetworkPlayerInfo playerInfo = new NetworkPlayerInfo();

    public void func_147297_a(Packet<?> packet) {
        this.sentPackets.add(packet);
    }

    public NetworkPlayerInfo func_175102_a(UUID id) {
        return this.playerInfo;
    }
}
