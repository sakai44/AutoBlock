package net.minecraft.client.network;

public class NetworkPlayerInfo {
    private int responseTime;

    public NetworkPlayerInfo() {
        this(0);
    }

    public NetworkPlayerInfo(int responseTime) {
        this.responseTime = responseTime;
    }

    public int func_178853_c() {
        return this.responseTime;
    }

    public void setResponseTime(int responseTime) {
        this.responseTime = responseTime;
    }
}
