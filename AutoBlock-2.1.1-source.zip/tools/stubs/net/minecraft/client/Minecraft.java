package net.minecraft.client;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.MovingObjectPosition;

public class Minecraft {
    private static final Minecraft INSTANCE = new Minecraft();

    public EntityPlayerSP field_71439_g;
    public WorldClient field_71441_e;
    public PlayerControllerMP field_71442_b;
    public GameSettings field_71474_y = new GameSettings();
    public FontRenderer field_71466_p = new FontRenderer();
    public MovingObjectPosition field_71476_x;
    public GuiScreen field_71462_r;
    public boolean field_71415_G = true;

    public static Minecraft func_71410_x() {
        return INSTANCE;
    }
}
