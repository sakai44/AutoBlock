package net.minecraft.client.gui;

public class FontRenderer {
    public int drawCalls;

    public int func_78256_a(String text) {
        return text == null ? 0 : text.length() * 6;
    }

    public int func_175063_a(String text, float x, float y, int color) {
        this.drawCalls++;
        return this.func_78256_a(text);
    }
}
