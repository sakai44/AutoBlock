package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;

public class ScaledResolution {
    public ScaledResolution(Minecraft minecraft) {
    }

    public int func_78326_a() {
        return 960;
    }

    public int func_78328_b() {
        return 540;
    }
}
