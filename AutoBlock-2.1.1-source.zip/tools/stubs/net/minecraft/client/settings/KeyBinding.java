package net.minecraft.client.settings;

public class KeyBinding {
    private boolean down;
    private final int code;
    private int field_151474_i;

    public KeyBinding() {
        this(0);
    }

    public KeyBinding(int code) {
        this.code = code;
    }

    public boolean func_151470_d() {
        return this.down;
    }

    public void setDown(boolean value) {
        this.down = value;
    }

    public int func_151463_i() {
        return this.code;
    }

    public static void func_74510_a(int code, boolean down) {
        net.minecraft.client.settings.GameSettings settings =
            net.minecraft.client.Minecraft.func_71410_x().field_71474_y;
        if (settings.field_74312_F.func_151463_i() == code) {
            settings.field_74312_F.setDown(down);
        }
        if (settings.field_74313_G.func_151463_i() == code) {
            settings.field_74313_G.setDown(down);
        }
    }

    public void setQueuedPresses(int count) {
        this.field_151474_i = count;
    }

    public static void func_74507_a(int code) {
        GameSettings settings = net.minecraft.client.Minecraft.func_71410_x().field_71474_y;
        if (settings.field_74312_F.func_151463_i() == code) {
            ++settings.field_74312_F.field_151474_i;
        }
        if (settings.field_74313_G.func_151463_i() == code) {
            ++settings.field_74313_G.field_151474_i;
        }
    }

    public boolean func_151468_f() {
        if (this.field_151474_i == 0) {
            return false;
        }
        --this.field_151474_i;
        return true;
    }

    public int drainQueuedPresses() {
        int count = this.field_151474_i;
        this.field_151474_i = 0;
        return count;
    }
}
