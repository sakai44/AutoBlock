package net.minecraft.client.settings;

public class GameSettings {
    public KeyBinding field_74312_F = new KeyBinding(-100);
    public KeyBinding field_74313_G = new KeyBinding(-99);
    public int field_74320_O;
}
