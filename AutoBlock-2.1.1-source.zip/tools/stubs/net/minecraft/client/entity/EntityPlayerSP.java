package net.minecraft.client.entity;

import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.MovementInput;

public class EntityPlayerSP extends AbstractClientPlayer {
    public NetHandlerPlayClient field_71174_a;
    public MovementInput field_71158_b = new MovementInput();
    public float field_70759_as;
    public float field_70761_aq;
    public float field_70758_at;
    public float field_70760_ar;

    public void func_71038_i() {
        if (this.field_71174_a != null) {
            this.field_71174_a.func_147297_a(new C0APacketAnimation());
        }
    }
}
