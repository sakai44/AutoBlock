package net.minecraft.client.multiplayer;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class WorldClient extends World {
    public IBlockState func_180495_p(BlockPos pos) {
        return null;
    }

    public MovingObjectPosition func_147447_a(
        Vec3 start,
        Vec3 end,
        boolean stopOnLiquid,
        boolean ignoreBlockWithoutBoundingBox,
        boolean returnLastUncollidable
    ) {
        return null;
    }

    public List<AxisAlignedBB> func_72945_a(
        Entity entity,
        AxisAlignedBB query
    ) {
        return this.func_147461_a(query);
    }

    /**
     * Vanilla's block-only collision query. Unlike func_72945_a it does not
     * require an Entity, which makes it safe for static world geometry tests.
     */
    public List<AxisAlignedBB> func_147461_a(AxisAlignedBB query) {
        List<AxisAlignedBB> boxes = new ArrayList<AxisAlignedBB>();
        int minX = floor(query.field_72340_a);
        int maxX = floor(query.field_72336_d);
        int minY = floor(query.field_72338_b);
        int maxY = floor(query.field_72337_e);
        int minZ = floor(query.field_72339_c);
        int maxZ = floor(query.field_72334_f);
        for (int x = minX; x <= maxX; ++x) {
            for (int y = minY; y <= maxY; ++y) {
                for (int z = minZ; z <= maxZ; ++z) {
                    IBlockState state = this.func_180495_p(
                        new BlockPos(x, y, z)
                    );
                    Block block = state == null ? null : state.func_177230_c();
                    if (
                        block != null
                            && block != Blocks.field_150350_a
                            && block.func_149730_j()
                    ) {
                        boxes.add(
                            new AxisAlignedBB(
                                x,
                                y,
                                z,
                                x + 1.0D,
                                y + 1.0D,
                                z + 1.0D
                            )
                        );
                    }
                }
            }
        }
        return boxes;
    }

    private static int floor(double value) {
        int truncated = (int) value;
        return value < truncated ? truncated - 1 : truncated;
    }
}
