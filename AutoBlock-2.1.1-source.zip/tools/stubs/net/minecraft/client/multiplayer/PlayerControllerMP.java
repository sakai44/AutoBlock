package net.minecraft.client.multiplayer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;

public class PlayerControllerMP {
    private final Minecraft minecraft;
    private int currentPlayerItem;
    public int useCalls;
    public int releaseCalls;

    public PlayerControllerMP(Minecraft minecraft) {
        this.minecraft = minecraft;
        EntityPlayerSP player = minecraft.field_71439_g;
        this.currentPlayerItem = player == null || player.field_71071_by == null
            ? -1
            : player.field_71071_by.field_70461_c;
    }

    public void func_78765_e() {
        EntityPlayerSP player = this.minecraft.field_71439_g;
        if (player != null) {
            this.syncCurrentPlayItem(player);
        }
    }

    public boolean func_78769_a(EntityPlayer player, World world, ItemStack stack) {
        ++this.useCalls;
        if (stack == null || !(stack.func_77973_b() instanceof net.minecraft.item.ItemSword)) {
            return false;
        }
        player.setUsingItem(true);
        return false;
    }

    public void func_78766_c(EntityPlayer player) {
        ++this.releaseCalls;
        player.setUsingItem(false);
    }

    public boolean func_178890_a(
        EntityPlayerSP player,
        WorldClient world,
        ItemStack stack,
        BlockPos clickedBlock,
        EnumFacing face,
        Vec3 hitVec
    ) {
        this.syncCurrentPlayItem(player);
        player.field_71174_a.func_147297_a(
            new C08PacketPlayerBlockPlacement(
                clickedBlock,
                face.func_176745_a(),
                stack,
                (float)(hitVec.field_72450_a - (double)clickedBlock.func_177958_n()),
                (float)(hitVec.field_72448_b - (double)clickedBlock.func_177956_o()),
                (float)(hitVec.field_72449_c - (double)clickedBlock.func_177952_p())
            )
        );
        return true;
    }

    private void syncCurrentPlayItem(EntityPlayerSP player) {
        int slot = player.field_71071_by.field_70461_c;
        if (slot != this.currentPlayerItem) {
            this.currentPlayerItem = slot;
            player.field_71174_a.func_147297_a(new C09PacketHeldItemChange(slot));
        }
    }
}
