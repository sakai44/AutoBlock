package net.minecraft.enchantment;

import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;

public final class EnchantmentHelper {
    private EnchantmentHelper() {
    }

    public static int func_77508_a(ItemStack[] armor, DamageSource source) {
        return 0;
    }
}
