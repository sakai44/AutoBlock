package net.minecraft.network.play.client;

import net.minecraft.network.Packet;

public class C0BPacketEntityAction implements Packet<Object> {
}
