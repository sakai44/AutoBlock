package net.minecraft.network.play.client;

import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.util.BlockPos;

public class C08PacketPlayerBlockPlacement implements Packet<Object> {
    public final BlockPos position;
    public final int direction;
    public final ItemStack stack;
    public final float hitX;
    public final float hitY;
    public final float hitZ;

    public C08PacketPlayerBlockPlacement(
        BlockPos position,
        int direction,
        ItemStack stack,
        float hitX,
        float hitY,
        float hitZ
    ) {
        this.position = position;
        this.direction = direction;
        this.stack = stack;
        this.hitX = hitX;
        this.hitY = hitY;
        this.hitZ = hitZ;
    }

    public ItemStack func_149574_g() {
        return this.stack;
    }
}
