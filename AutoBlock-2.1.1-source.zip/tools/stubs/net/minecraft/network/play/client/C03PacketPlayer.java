package net.minecraft.network.play.client;

import net.minecraft.network.Packet;

public class C03PacketPlayer implements Packet<Object> {
    protected double field_149479_a;
    protected double field_149477_b;
    protected double field_149478_c;
    protected float field_149476_e;
    protected float field_149473_f;
    protected boolean field_149474_g;

    public C03PacketPlayer() {
    }

    public C03PacketPlayer(boolean onGround) {
        this.field_149474_g = onGround;
    }

    public static class C04PacketPlayerPosition extends C03PacketPlayer {
        public C04PacketPlayerPosition(
            double x,
            double y,
            double z,
            boolean onGround
        ) {
            this.field_149479_a = x;
            this.field_149477_b = y;
            this.field_149478_c = z;
            this.field_149474_g = onGround;
        }
    }

    public static class C05PacketPlayerLook extends C03PacketPlayer {
        public C05PacketPlayerLook(float yaw, float pitch, boolean onGround) {
            this.field_149476_e = yaw;
            this.field_149473_f = pitch;
            this.field_149474_g = onGround;
        }
    }

    public static class C06PacketPlayerPosLook extends C03PacketPlayer {
        public C06PacketPlayerPosLook(
            double x,
            double y,
            double z,
            float yaw,
            float pitch,
            boolean onGround
        ) {
            this.field_149479_a = x;
            this.field_149477_b = y;
            this.field_149478_c = z;
            this.field_149476_e = yaw;
            this.field_149473_f = pitch;
            this.field_149474_g = onGround;
        }
    }
}
