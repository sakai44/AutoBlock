package net.minecraft.network.play.client;

import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class C02PacketUseEntity implements Packet<Object> {
    public enum Action {
        INTERACT,
        ATTACK,
        INTERACT_AT
    }

    private final int entityId;
    private final Action action;
    private final Vec3 hitVec;

    public C02PacketUseEntity(int entityId, Action action) {
        this.entityId = entityId;
        this.action = action;
        this.hitVec = null;
    }

    public C02PacketUseEntity(Entity entity, Action action) {
        this(0, action);
    }

    public C02PacketUseEntity(Entity entity, Vec3 hitVec) {
        this(0, Action.INTERACT_AT);
    }

    public Entity func_149564_a(World worldIn) {
        return worldIn == null ? null : worldIn.func_73045_a(this.entityId);
    }

    public Action func_149565_c() {
        return this.action;
    }

    public Vec3 func_179712_b() {
        return this.hitVec;
    }
}
