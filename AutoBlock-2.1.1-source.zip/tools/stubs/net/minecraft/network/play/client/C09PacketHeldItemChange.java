package net.minecraft.network.play.client;

import net.minecraft.network.Packet;

public class C09PacketHeldItemChange implements Packet<Object> {
    public final int slot;

    public C09PacketHeldItemChange(int slot) {
        this.slot = slot;
    }
}
