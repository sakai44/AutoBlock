package net.minecraft.network.play.server;

import net.minecraft.block.state.IBlockState;
import net.minecraft.network.Packet;
import net.minecraft.util.BlockPos;

/** Minimal 1.8.9 shape used to compile multi-block diagnostics. */
public class S22PacketMultiBlockChange implements Packet<Object> {
    private final BlockUpdateData[] changedBlocks;

    public S22PacketMultiBlockChange(BlockUpdateData[] changedBlocks) {
        this.changedBlocks = changedBlocks;
    }

    public BlockUpdateData[] func_179844_a() {
        return this.changedBlocks;
    }

    public static class BlockUpdateData {
        private final BlockPos position;
        private final IBlockState state;

        public BlockUpdateData(BlockPos position, IBlockState state) {
            this.position = position;
            this.state = state;
        }

        public BlockPos func_180090_a() {
            return this.position;
        }

        public IBlockState func_180088_c() {
            return this.state;
        }
    }
}
