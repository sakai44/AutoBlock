package net.minecraft.network.play.server;

import net.minecraft.network.Packet;

public class S08PacketPlayerPosLook implements Packet<Object> {
}
