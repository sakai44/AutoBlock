package net.minecraft.network.play.server;

import net.minecraft.network.Packet;

public class S12PacketEntityVelocity implements Packet<Object> {
    private final int entityId;
    private final int motionX;
    private final int motionY;
    private final int motionZ;

    public S12PacketEntityVelocity(
        int entityId,
        int motionX,
        int motionY,
        int motionZ
    ) {
        this.entityId = entityId;
        this.motionX = motionX;
        this.motionY = motionY;
        this.motionZ = motionZ;
    }

    public int func_149412_c() {
        return this.entityId;
    }

    public int func_149411_d() {
        return this.motionX;
    }

    public int func_149410_e() {
        return this.motionY;
    }

    public int func_149409_f() {
        return this.motionZ;
    }
}
