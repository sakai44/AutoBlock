package net.minecraft.network.play.server;

import net.minecraft.network.Packet;

public class S19PacketEntityStatus implements Packet<Object> {
    private final int entityId;
    private final byte opCode;

    public S19PacketEntityStatus(int entityId, byte opCode) {
        this.entityId = entityId;
        this.opCode = opCode;
    }

    public int func_149160_c() {
        return this.entityId;
    }

    public byte func_149153_d() {
        return this.opCode;
    }
}
