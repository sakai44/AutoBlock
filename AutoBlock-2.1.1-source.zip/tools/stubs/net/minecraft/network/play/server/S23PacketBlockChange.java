package net.minecraft.network.play.server;

import net.minecraft.block.state.IBlockState;
import net.minecraft.network.Packet;
import net.minecraft.util.BlockPos;

/** Minimal 1.8.9 shape used to compile packet-observation diagnostics. */
public class S23PacketBlockChange implements Packet<Object> {
    private final BlockPos position;
    private final IBlockState state;

    public S23PacketBlockChange(BlockPos position, IBlockState state) {
        this.position = position;
        this.state = state;
    }

    public BlockPos func_179827_b() {
        return this.position;
    }

    public IBlockState func_180728_a() {
        return this.state;
    }
}
