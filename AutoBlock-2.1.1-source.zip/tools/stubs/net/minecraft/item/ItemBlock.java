package net.minecraft.item;

import net.minecraft.block.Block;

public class ItemBlock extends Item {
    private final Block block;

    public ItemBlock() {
        this(null);
    }

    public ItemBlock(Block block) {
        this.block = block;
    }

    public Block func_179223_d() {
        return this.block;
    }
}
