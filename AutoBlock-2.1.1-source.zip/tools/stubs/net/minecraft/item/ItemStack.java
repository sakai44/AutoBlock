package net.minecraft.item;

public class ItemStack {
    private final Item item;
    public int field_77994_a = 1;

    public ItemStack() {
        this(null);
    }

    public ItemStack(Item item) {
        this.item = item;
    }

    public Item func_77973_b() {
        return this.item;
    }
}
