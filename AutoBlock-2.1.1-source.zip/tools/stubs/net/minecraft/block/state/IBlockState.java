package net.minecraft.block.state;

import net.minecraft.block.Block;

public interface IBlockState {
    Block func_177230_c();
}
