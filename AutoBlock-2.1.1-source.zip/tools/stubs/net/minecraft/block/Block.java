package net.minecraft.block;

public class Block {
    private final String name;
    private final boolean full;

    public Block() {
        this("", true);
    }

    public Block(String name, boolean full) {
        this.name = name;
        this.full = full;
    }

    public String func_149739_a() {
        return this.name;
    }

    public boolean func_149730_j() {
        return this.full;
    }
}
