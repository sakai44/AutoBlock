package net.minecraft.init;

import net.minecraft.item.Item;

public final class Items {
    public static final Item field_151079_bi = new Item();

    private Items() {
    }
}
