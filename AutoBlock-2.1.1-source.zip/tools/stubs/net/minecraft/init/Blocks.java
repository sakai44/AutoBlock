package net.minecraft.init;

import net.minecraft.block.Block;

public final class Blocks {
    public static final Block field_150350_a = new Block("tile.air", false);

    private Blocks() {
    }
}
