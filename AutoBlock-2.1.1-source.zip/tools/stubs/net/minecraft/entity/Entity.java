package net.minecraft.entity;

import java.util.UUID;

public class Entity {
    public double field_70165_t;
    public double field_70163_u;
    public double field_70161_v;
    public double field_70159_w;
    public double field_70181_x;
    public double field_70179_y;
    public float field_70177_z;
    public float field_70125_A;
    public float field_70126_B;
    public float field_70127_C;
    public float field_70143_R;
    public boolean field_70122_E;
    public boolean field_70128_L;
    public int field_70172_ad;
    private net.minecraft.util.AxisAlignedBB box;
    private final UUID persistentId = UUID.randomUUID();
    private int entityId;

    public float func_70047_e() {
        return 1.62F;
    }

    public boolean func_70090_H() {
        return false;
    }

    public UUID func_110124_au() {
        return this.persistentId;
    }

    public int func_145782_y() {
        return this.entityId;
    }

    public boolean func_70089_S() {
        return !this.field_70128_L;
    }

    public net.minecraft.util.AxisAlignedBB func_174813_aQ() {
        return this.box;
    }

    public void setBoundingBox(net.minecraft.util.AxisAlignedBB box) {
        this.box = box;
    }

    public void setEntityId(int entityId) {
        this.entityId = entityId;
    }
}
