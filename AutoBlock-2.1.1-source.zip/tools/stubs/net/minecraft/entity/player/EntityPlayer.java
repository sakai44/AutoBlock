package net.minecraft.entity.player;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.item.ItemStack;

public class EntityPlayer extends EntityLivingBase {
    public InventoryPlayer field_71071_by;
    private float health = 20.0F;
    private boolean usingItem;

    public boolean func_70617_f_() {
        return false;
    }

    public float func_110143_aJ() {
        return this.health;
    }

    public void setHealth(float health) {
        this.health = health;
    }

    public ItemStack func_70694_bm() {
        return this.field_71071_by == null ? null : this.field_71071_by.func_70301_a(this.field_71071_by.field_70461_c);
    }

    public boolean func_71039_bw() {
        return this.usingItem;
    }

    public void setUsingItem(boolean usingItem) {
        this.usingItem = usingItem;
    }

    public PotionEffect func_70660_b(Potion potion) {
        return null;
    }
}
