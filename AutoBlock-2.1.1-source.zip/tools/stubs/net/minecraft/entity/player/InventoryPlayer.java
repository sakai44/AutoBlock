package net.minecraft.entity.player;

import net.minecraft.item.ItemStack;

public class InventoryPlayer {
    public int field_70461_c;
    private final ItemStack[] hotbar = new ItemStack[9];

    public ItemStack func_70301_a(int slot) {
        return this.hotbar[slot];
    }

    public ItemStack func_70440_f(int slot) {
        return null;
    }

    public void setStackInSlot(int slot, ItemStack stack) {
        this.hotbar[slot] = stack;
    }
}
