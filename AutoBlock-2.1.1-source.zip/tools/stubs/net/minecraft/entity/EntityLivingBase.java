package net.minecraft.entity;

public class EntityLivingBase extends Entity {
    public int field_70737_aN;
    public int field_70771_an = 20;
}
