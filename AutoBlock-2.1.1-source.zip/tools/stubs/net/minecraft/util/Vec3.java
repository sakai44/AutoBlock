package net.minecraft.util;

public class Vec3 {
    public final double field_72450_a;
    public final double field_72448_b;
    public final double field_72449_c;

    public Vec3(double x, double y, double z) {
        this.field_72450_a = x;
        this.field_72448_b = y;
        this.field_72449_c = z;
    }
}
