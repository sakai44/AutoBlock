package net.minecraft.util;

public enum EnumFacing {
    DOWN(0, 0, -1, 0),
    UP(1, 0, 1, 0),
    NORTH(2, 0, 0, -1),
    SOUTH(3, 0, 0, 1),
    WEST(4, -1, 0, 0),
    EAST(5, 1, 0, 0);

    private final int index;
    private final int x;
    private final int y;
    private final int z;

    EnumFacing(int index, int x, int y, int z) {
        this.index = index;
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public int func_176745_a() {
        return this.index;
    }

    public int func_82601_c() {
        return this.x;
    }

    public int func_96559_d() {
        return this.y;
    }

    public int func_82599_e() {
        return this.z;
    }

    public EnumFacing func_176734_d() {
        switch (this) {
            case DOWN:
                return UP;
            case UP:
                return DOWN;
            case NORTH:
                return SOUTH;
            case SOUTH:
                return NORTH;
            case WEST:
                return EAST;
            default:
                return WEST;
        }
    }
}
