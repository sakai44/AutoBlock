package net.minecraft.util;

public enum EnumChatFormatting {
    WHITE,
    GREEN,
    BOLD,
    RED
}
