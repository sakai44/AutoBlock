package net.minecraft.util;

public class DamageSource {
    public static final DamageSource field_76379_h = new DamageSource();
}
