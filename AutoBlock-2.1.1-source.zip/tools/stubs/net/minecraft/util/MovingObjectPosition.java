package net.minecraft.util;

import net.minecraft.entity.Entity;

public class MovingObjectPosition {
    public MovingObjectType field_72313_a;
    public EnumFacing field_178784_b;
    public Vec3 field_72307_f;
    public Entity field_72308_g;
    private BlockPos blockPos;

    public MovingObjectPosition() {
    }

    public MovingObjectPosition(BlockPos blockPos, EnumFacing side) {
        this.field_72313_a = MovingObjectType.BLOCK;
        this.field_178784_b = side;
        this.blockPos = blockPos;
    }

    public BlockPos func_178782_a() {
        return this.blockPos;
    }

    public enum MovingObjectType {
        MISS,
        BLOCK,
        ENTITY
    }
}
