package net.minecraft.util;

public class AxisAlignedBB {
    public final double field_72340_a;
    public final double field_72338_b;
    public final double field_72339_c;
    public final double field_72336_d;
    public final double field_72337_e;
    public final double field_72334_f;

    public AxisAlignedBB(
        double minX,
        double minY,
        double minZ,
        double maxX,
        double maxY,
        double maxZ
    ) {
        this.field_72340_a = minX;
        this.field_72338_b = minY;
        this.field_72339_c = minZ;
        this.field_72336_d = maxX;
        this.field_72337_e = maxY;
        this.field_72334_f = maxZ;
    }
}
