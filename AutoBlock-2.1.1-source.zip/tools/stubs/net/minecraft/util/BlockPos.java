package net.minecraft.util;

public class BlockPos {
    private final int x;
    private final int y;
    private final int z;

    public BlockPos(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public int func_177958_n() {
        return this.x;
    }

    public int func_177956_o() {
        return this.y;
    }

    public int func_177952_p() {
        return this.z;
    }

    public BlockPos func_177972_a(EnumFacing facing) {
        return new BlockPos(
            this.x + facing.func_82601_c(),
            this.y + facing.func_96559_d(),
            this.z + facing.func_82599_e()
        );
    }

    public BlockPos func_177977_b() {
        return new BlockPos(this.x, this.y - 1, this.z);
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof BlockPos)) {
            return false;
        }
        BlockPos pos = (BlockPos)other;
        return this.x == pos.x && this.y == pos.y && this.z == pos.z;
    }

    @Override
    public int hashCode() {
        int result = this.x;
        result = 31 * result + this.y;
        result = 31 * result + this.z;
        return result;
    }

    @Override
    public String toString() {
        return this.x + "," + this.y + "," + this.z;
    }
}
