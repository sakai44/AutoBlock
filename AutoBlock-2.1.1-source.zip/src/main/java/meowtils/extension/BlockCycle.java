/*
 * Decompiled with CFR 0.152.
 */
package meowtils.extension;

final class BlockCycle {
    private State state = State.INACTIVE;
    private long startedAtNanos;

    BlockCycle() {
    }

    State state() {
        return this.state;
    }

    void reset() {
        this.state = State.INACTIVE;
        this.startedAtNanos = 0L;
    }

    void armForDamage() {
        this.state = State.WAITING;
    }

    boolean shouldStart(boolean windowOpen, int holdMillis) {
        if (!windowOpen) {
            return false;
        }
        if (holdMillis <= 0) {
            if (this.state == State.WAITING) {
                this.exhaust();
            }
            return false;
        }
        return this.state == State.WAITING;
    }

    void begin(long nowNanos) {
        this.state = State.BLOCKING;
        this.startedAtNanos = nowNanos;
    }

    boolean holdExpired(long nowNanos, int holdMillis) {
        return this.state == State.BLOCKING && (holdMillis <= 0 || nowNanos - this.startedAtNanos >= (long)holdMillis * 1000000L);
    }

    void exhaust() {
        this.state = State.EXHAUSTED;
    }

    static enum State {
        INACTIVE,
        WAITING,
        BLOCKING,
        EXHAUSTED;

    }
}

