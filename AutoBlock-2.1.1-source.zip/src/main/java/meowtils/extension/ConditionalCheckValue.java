package meowtils.extension;

import java.util.function.BooleanSupplier;
import wtf.tatp.meowtils.gui.component.ModuleComponent;
import wtf.tatp.meowtils.gui.component.subcomponents.CheckComponent;
import wtf.tatp.meowtils.gui.values.CheckValue;

/** Keeps a saved check setting out of the layout when its mode is inactive. */
final class ConditionalCheckValue extends CheckValue {
    private final BooleanSupplier visible;

    ConditionalCheckValue(String name, String fieldName, Object owner, BooleanSupplier visible) {
        super(name, fieldName, owner);
        this.visible = visible;
    }

    @Override
    public CheckComponent createComponent(ModuleComponent component, int offset) {
        return new ConditionalCheckComponent(this, component, offset, this.visible);
    }
}
