package meowtils.extension;

import java.util.function.BooleanSupplier;
import wtf.tatp.meowtils.gui.component.ModuleComponent;
import wtf.tatp.meowtils.gui.component.subcomponents.SliderComponent;
import wtf.tatp.meowtils.gui.values.SliderValue;

/** Keeps a saved slider setting out of the layout when its mode is inactive. */
final class ConditionalSliderValue extends SliderValue {
    private final BooleanSupplier visible;

    ConditionalSliderValue(String name, double min, double max, double increment, String valueType,
            String fieldName, Object owner, Class<?> targetType, BooleanSupplier visible) {
        super(name, min, max, increment, valueType, fieldName, owner, targetType);
        this.visible = visible;
    }

    @Override
    public SliderComponent createComponent(ModuleComponent component, int offset) {
        return new ConditionalSliderComponent(this, component, offset, this.visible);
    }
}
