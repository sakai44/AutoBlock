package meowtils.extension;

/** Client-clock cadence for Timed mode; a gap starts when a held block ends. */
final class TimedCycle {
    enum State { READY, HOLDING, GAP }

    private State state = State.READY;
    private long phaseStartedNanos;

    State state() {
        return this.state;
    }

    void reset() {
        this.state = State.READY;
        this.phaseStartedNanos = 0L;
    }

    void beginHold(long nowNanos) {
        this.state = State.HOLDING;
        this.phaseStartedNanos = nowNanos;
    }

    boolean holdExpired(long nowNanos, int holdMillis) {
        return this.state == State.HOLDING
            && elapsed(nowNanos, this.phaseStartedNanos, holdMillis);
    }

    void beginGap(long nowNanos) {
        this.state = State.GAP;
        this.phaseStartedNanos = nowNanos;
    }

    boolean ready(long nowNanos, int gapMillis) {
        return this.state == State.READY
            || this.state == State.GAP && elapsed(nowNanos, this.phaseStartedNanos, gapMillis);
    }

    private static boolean elapsed(long nowNanos, long startNanos, int millis) {
        return nowNanos - startNanos >= (long)Math.max(0, Math.min(500, millis)) * 1000000L;
    }
}
