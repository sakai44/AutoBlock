package meowtils.extension;

import java.util.function.BooleanSupplier;
import wtf.tatp.meowtils.gui.component.ModuleComponent;
import wtf.tatp.meowtils.gui.component.subcomponents.CheckComponent;
import wtf.tatp.meowtils.gui.values.CheckValue;

/** Removes an inactive mode's check row and blocks clicks on its old position. */
final class ConditionalCheckComponent extends CheckComponent {
    private final BooleanSupplier visible;

    ConditionalCheckComponent(CheckValue option, ModuleComponent component, int offset, BooleanSupplier visible) {
        super(option, component, offset);
        this.visible = visible;
    }

    private boolean isVisible() {
        return this.visible != null && this.visible.getAsBoolean();
    }

    @Override public void render() {
        if (this.isVisible()) super.render();
    }

    @Override public void updateComponent(int mouseX, int mouseY) {
        if (this.isVisible()) super.updateComponent(mouseX, mouseY);
    }

    @Override public boolean mouseClicked(int mouseX, int mouseY, int button) {
        return this.isVisible() && super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public int getHeight() {
        return this.isVisible() ? super.getHeight() : 0;
    }
}
