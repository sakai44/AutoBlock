package meowtils.extension;

import java.util.Arrays;
import java.util.function.LongSupplier;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import wtf.tatp.meowtils.config.Config;
import wtf.tatp.meowtils.event.AttackEntityEvent;
import wtf.tatp.meowtils.event.ClientTickEvent;
import wtf.tatp.meowtils.event.MouseInputEvent;
import wtf.tatp.meowtils.event.RenderTickEvent;
import wtf.tatp.meowtils.event.WorldEvent;
import wtf.tatp.meowtils.event.api.EventPriority;
import wtf.tatp.meowtils.event.api.EventTarget;
import wtf.tatp.meowtils.extension.Extension;

public final class AutoBlock
extends Extension {
    private static final long CLICK_GRACE_NANOS = 150000000L;
    @Config
    public boolean enabled = false;
    @Config
    public int key = 0;
    @Config
    public boolean checkLeftClick = true;
    @Config
    public boolean checkRightClick = false;
    @Config
    public boolean checkTookDamage = false;
    @Config
    public float range = 3.5f;
    @Config
    public int maximumHurtTime = -1;
    @Config
    public int maximumHurtTicks = 4;
    @Config
    public int maximumHoldDuration = 150;
    @Config
    public volatile String mode = "Predict";
    @Config
    public int timedBlockDuration = 100;
    @Config
    public int timeBetweenBlocks = 400;
    private final LongSupplier clock;
    private final BlockCycle cycle = new BlockCycle();
    private final TimedCycle timedCycle = new TimedCycle();
    private EntityLivingBase target;
    private volatile String activeMode = "Predict";
    private WorldClient observedWorld;
    private EntityPlayerSP observedPlayer;
    private int previousResistanceTicks;
    private int previousHurtTicks;
    private long lastAttackNanos = Long.MIN_VALUE;
    private long lastUnhurtArmNanos = Long.MIN_VALUE;
    private boolean ownsBlock;
    private boolean vanillaReleasePending;
    private boolean timedStartPending;
    private boolean timedStartAttempted;
    private boolean timedGapPending;
    private boolean manualReleasePending;
    private int manualUseKeyCode;
    private int ownedUseKeyCode;

    public AutoBlock() {
        this(new LongSupplier(){

            @Override
            public long getAsLong() {
                return System.nanoTime();
            }
        });
    }

    AutoBlock(LongSupplier clock) {
        super("AutoBlock", "Codex");
        this.clock = clock;
        this.mode("Mode", Arrays.asList("Predict", "Timed"), "mode");
        this.addCheck(new ConditionalCheckValue(
            "Check Left Click", "checkLeftClick", this, () -> true
        ));
        this.addCheck(new ConditionalCheckValue(
            "Check Right Click", "checkRightClick", this, () -> true
        ));
        this.addCheck(new ConditionalCheckValue(
            "Check Took Damage", "checkTookDamage", this, () -> true
        ));
        this.addSlider(new ConditionalSliderValue(
            "Range", 0.0, 6.0, 0.1, " blocks", "range", this, Float.TYPE,
            () -> true
        ));
        this.addSlider(new ConditionalSliderValue(
            "Maximum hurt time", 0.0, 10.0, 1.0, " ticks", "maximumHurtTicks", this, Integer.TYPE,
            () -> !this.isTimedMode()
        ));
        this.addSlider(new ConditionalSliderValue(
            "Maximum hold duration", 0.0, 500.0, 10.0, " ms", "maximumHoldDuration", this, Integer.TYPE,
            () -> !this.isTimedMode()
        ));
        this.addSlider(new ConditionalSliderValue(
            "Block duration", 0.0, 500.0, 10.0, " ms", "timedBlockDuration", this, Integer.TYPE,
            this::isTimedMode
        ));
        this.addSlider(new ConditionalSliderValue(
            "Time between blocks", 0.0, 500.0, 10.0, " ms", "timeBetweenBlocks", this, Integer.TYPE,
            this::isTimedMode
        ));
        this.tooltip("Predict uses the 1.0.7 hurt-time cycle. Timed alternates client-timed blocks and gaps.");
    }

    public void onEnable() {
        this.clearAll();
        this.activeMode = this.selectedMode();
        this.observedWorld = this.mc.field_71441_e;
        this.observedPlayer = this.mc.field_71439_g;
        this.previousResistanceTicks = this.observedPlayer == null ? 0 : Math.max(0, this.observedPlayer.field_70172_ad);
        this.previousHurtTicks = this.observedPlayer == null ? 0 : Math.max(0, this.observedPlayer.field_70737_aN);
    }

    public void onDisable() {
        this.clearAll();
    }

    public void onReset() {
        this.clearAll();
    }

    @EventTarget(priority=EventPriority.LOWEST)
    public void onClientTick(ClientTickEvent event) {
        if (!this.enabled || event == null) {
            return;
        }
        try {
            this.syncModeFromSetting();
            this.migrateHurtTime();
            if (event.getPhase() == ClientTickEvent.Phase.PRE) {
                if (this.isTimedMode()) {
                    this.beforeTimedInput();
                } else {
                    this.beforePredictInput();
                }
            } else if (event.getPhase() == ClientTickEvent.Phase.POST) {
                this.finishTimedStart();
                this.finishVanillaRelease();
                this.finishManualRelease();
            }
        }
        catch (RuntimeException failure) {
            this.clearAll();
        }
    }

    @EventTarget(priority=EventPriority.HIGHEST)
    public void onRenderTick(RenderTickEvent event) {
        if (!this.enabled || event == null || event.getPhase() != RenderTickEvent.Phase.PRE) {
            return;
        }
        try {
            this.syncModeFromSetting();
            this.migrateHurtTime();
            if (!this.syncSession()) {
                return;
            }
            EntityPlayerSP player = this.mc.field_71439_g;
            if (this.ownsBlock && !this.basicContextValid(player)) {
                this.endBlock();
                this.cycle.exhaust();
                this.timedCycle.reset();
                return;
            }
            if (this.isTimedMode()) {
                this.updateTimed(this.clock.getAsLong(), false);
            } else {
                this.expireHoldIfDue(this.clock.getAsLong());
            }
        }
        catch (RuntimeException failure) {
            this.clearAll();
        }
    }

    private void migrateHurtTime() {
        if (this.maximumHurtTime >= 0) {
            this.maximumHurtTicks = AutoBlockTiming.migrateHurtMillisToTicks(this.maximumHurtTime);
            this.maximumHurtTime = -1;
        }
    }

    @EventTarget(priority=EventPriority.HIGHEST)
    public void onMouseInput(MouseInputEvent event) {
        if (!this.enabled || event == null) {
            return;
        }
        try {
            if (event.getAction() == MouseInputEvent.Action.RIGHT_CLICK && this.timedStartPending) {
                // Vanilla has consumed the queued press and is now processing use input.
                this.timedStartPending = false;
                long now = this.clock.getAsLong();
                EntityPlayerSP player = this.mc.field_71439_g;
                if (this.isTimedMode() && this.syncSession()
                    && this.timedInputValid(player, now) && !player.func_71039_bw()
                    && this.timedBlockDuration > 0) {
                    this.ownsBlock = true;
                    this.timedStartAttempted = true;
                    KeyBinding.func_74510_a(this.ownedUseKeyCode, true);
                    this.timedCycle.beginHold(now);
                    return; // Let vanilla send its normal right-click action.
                }
                KeyBinding.func_74510_a(this.ownedUseKeyCode,
                    this.physicalCodeDown(this.ownedUseKeyCode));
                this.timedCycle.reset();
                event.setCancelled(true);
                return;
            }
            if (event.getAction() == MouseInputEvent.Action.RIGHT_CLICK && (this.ownsBlock
                || this.isTimedMode() && this.timedCycle.state() == TimedCycle.State.GAP
                    && this.timedInputValid(this.mc.field_71439_g, this.clock.getAsLong())
                || this.checkRightClick && this.hasSword(this.mc.field_71439_g) && this.physicalDown(this.mc.field_71474_y.field_74313_G) && this.attackIntent(this.clock.getAsLong()))) {
                event.setCancelled(true);
            }
        }
        catch (RuntimeException failure) {
            this.clearAll();
        }
    }

    @EventTarget(priority=EventPriority.HIGHEST)
    public void onAttackEntity(AttackEntityEvent event) {
        if (!this.enabled || event == null || event.getPlayer() != this.mc.field_71439_g) {
            return;
        }
        try {
            long now;
            Entity attacked = event.getTarget();
            if (!this.hasSword(this.mc.field_71439_g) || !(attacked instanceof EntityLivingBase)) {
                this.clearTarget();
                return;
            }
            if (attacked != this.target) {
                if (this.ownsBlock) {
                    this.endBlock();
                    this.cycle.exhaust();
                }
                this.timedCycle.reset();
            }
            this.target = (EntityLivingBase)attacked;
            this.lastAttackNanos = now = this.clock.getAsLong();
            EntityPlayerSP player = this.mc.field_71439_g;
            if (this.isTimedMode()) {
                return;
            }
            if (!(this.checkTookDamage || player.field_70172_ad > 0 || this.cycle.state() != BlockCycle.State.INACTIVE && this.cycle.state() != BlockCycle.State.EXHAUSTED || !this.targetInsideRange(player) || this.lastUnhurtArmNanos != Long.MIN_VALUE && now - this.lastUnhurtArmNanos < AutoBlockTiming.unhurtAttackCycleNanos(player.field_70771_an))) {
                this.cycle.armForDamage();
                this.lastUnhurtArmNanos = now;
            }
        }
        catch (RuntimeException failure) {
            this.clearAll();
        }
    }

    @EventTarget
    public void onWorldEvent(WorldEvent event) {
        this.clearAll();
    }

    private void syncModeFromSetting() {
        String selected = this.selectedMode();
        if (selected.equals(this.activeMode)) {
            return;
        }
        if (this.ownsBlock) {
            this.endBlock();
        }
        this.clearTransientState();
        this.activeMode = selected;
        this.observedWorld = this.mc.field_71441_e;
        this.observedPlayer = this.mc.field_71439_g;
        this.previousResistanceTicks = this.observedPlayer == null
            ? 0 : Math.max(0, this.observedPlayer.field_70172_ad);
        this.previousHurtTicks = this.observedPlayer == null
            ? 0 : Math.max(0, this.observedPlayer.field_70737_aN);
    }

    private String selectedMode() {
        String selected = "Timed".equalsIgnoreCase(this.mode) ? "Timed" : "Predict";
        // Older saved Cycle values now select the retained, renamed mode.
        if (!selected.equals(this.mode)) {
            this.mode = selected;
        }
        return selected;
    }

    private boolean isTimedMode() {
        return "Timed".equals(this.selectedMode());
    }

    private void beforeTimedInput() {
        if (!this.syncSession()) {
            return;
        }
        EntityPlayerSP player = this.mc.field_71439_g;
        if (player == null) {
            return;
        }
        if (this.vanillaReleasePending) {
            KeyBinding.func_74510_a(this.ownedUseKeyCode, false);
            return;
        }
        if (this.manualReleasePending) {
            if (player.func_71039_bw()) {
                KeyBinding.func_74510_a(this.manualUseKeyCode, false);
                return;
            }
            this.finishManualRelease();
        }
        if (this.checkRightClick && !this.ownsBlock && player.func_71039_bw()
            && this.hasSword(player)
            && this.physicalDown(this.mc.field_71474_y.field_74313_G)
            && this.attackIntent(this.clock.getAsLong())) {
            this.manualUseKeyCode = this.mc.field_71474_y.field_74313_G.func_151463_i();
            this.manualReleasePending = true;
            KeyBinding.func_74510_a(this.manualUseKeyCode, false);
            return;
        }
        this.updateTimed(this.clock.getAsLong(), true);
    }

    private void updateTimed(long now, boolean allowStart) {
        if (!this.syncSession() || this.vanillaReleasePending || this.manualReleasePending) {
            return;
        }
        EntityPlayerSP player = this.mc.field_71439_g;
        if (!(this.basicContextValid(player) && this.targetValid(player)
            && this.targetInsideRange(player))) {
            this.clearTarget();
            return;
        }
        boolean leftDown = this.attackIntent(now);
        boolean rightDown = this.physicalDown(this.mc.field_71474_y.field_74313_G);
        boolean tookDamage = player.field_70172_ad > 0;
        if (!AutoBlockTiming.conditionsPass(this.checkLeftClick, this.checkRightClick,
            this.checkTookDamage, leftDown, rightDown, tookDamage)) {
            this.cancelTimedStart();
            if (this.ownsBlock) {
                this.endBlock();
            }
            this.timedCycle.reset();
            return;
        }

        int holdMillis = Math.max(0, Math.min(500, this.timedBlockDuration));
        if (this.timedCycle.state() == TimedCycle.State.HOLDING) {
            if (!this.ownsBlock) {
                this.timedCycle.reset();
            } else if (this.timedCycle.holdExpired(now, holdMillis)) {
                this.timedGapPending = true;
                this.scheduleVanillaRelease();
            }
            return;
        }
        if (this.ownsBlock) {
            this.endBlock();
            this.timedCycle.reset();
            return;
        }
        if (holdMillis == 0) {
            this.cancelTimedStart();
            return;
        }
        if (!allowStart || this.timedStartPending
            || !this.timedCycle.ready(now, this.timeBetweenBlocks)
            || player.func_71039_bw()) {
            return;
        }
        this.queueTimedStart();
    }

    private boolean timedInputValid(EntityPlayerSP player, long now) {
        return this.basicContextValid(player) && this.targetValid(player)
            && this.targetInsideRange(player)
            && AutoBlockTiming.conditionsPass(this.checkLeftClick, this.checkRightClick,
                this.checkTookDamage, this.attackIntent(now),
                this.physicalDown(this.mc.field_71474_y.field_74313_G),
                player.field_70172_ad > 0);
    }

    private void queueTimedStart() {
        this.ownedUseKeyCode = this.mc.field_71474_y.field_74313_G.func_151463_i();
        if (this.ownedUseKeyCode == 0
            || this.ownedUseKeyCode == this.mc.field_71474_y.field_74312_F.func_151463_i()) {
            return;
        }
        this.timedStartPending = true;
        KeyBinding.func_74510_a(this.ownedUseKeyCode, true);
        KeyBinding.func_74507_a(this.ownedUseKeyCode);
    }

    private void cancelTimedStart() {
        if (!this.timedStartPending) {
            return;
        }
        this.timedStartPending = false;
        // Remove our one queued press without draining the user's other presses.
        this.mc.field_71474_y.field_74313_G.func_151468_f();
        KeyBinding.func_74510_a(this.ownedUseKeyCode,
            this.physicalCodeDown(this.ownedUseKeyCode));
    }

    private void finishTimedStart() {
        if (!this.timedStartAttempted) {
            return;
        }
        this.timedStartAttempted = false;
        EntityPlayerSP player = this.mc.field_71439_g;
        if (player == null || !player.func_71039_bw()) {
            // Another listener or an interaction may have prevented sword use.
            this.ownsBlock = false;
            this.timedCycle.reset();
            KeyBinding.func_74510_a(this.ownedUseKeyCode,
                this.physicalCodeDown(this.ownedUseKeyCode));
        }
    }

    private void beforePredictInput() {
        boolean windowOpen;
        boolean rightDown;
        boolean leftDown;
        if (!this.syncSession()) {
            return;
        }
        EntityPlayerSP player = this.mc.field_71439_g;
        if (player == null) {
            return;
        }
        int resistanceTicks = Math.max(0, player.field_70172_ad);
        int hurtTicks = Math.max(0, player.field_70737_aN);
        if (resistanceTicks > this.previousResistanceTicks || hurtTicks > this.previousHurtTicks) {
            this.endBlock();
            this.cycle.armForDamage();
        }
        this.previousResistanceTicks = resistanceTicks;
        this.previousHurtTicks = hurtTicks;
        if (this.vanillaReleasePending) {
            KeyBinding.func_74510_a((int)this.ownedUseKeyCode, (boolean)false);
            return;
        }
        if (this.manualReleasePending) {
            if (player.func_71039_bw()) {
                KeyBinding.func_74510_a((int)this.manualUseKeyCode, (boolean)false);
                return;
            }
            this.finishManualRelease();
        }
        if (this.checkRightClick && !this.ownsBlock && player.func_71039_bw() && this.hasSword(player) && this.physicalDown(this.mc.field_71474_y.field_74313_G) && this.attackIntent(this.clock.getAsLong())) {
            this.manualUseKeyCode = this.mc.field_71474_y.field_74313_G.func_151463_i();
            this.manualReleasePending = true;
            KeyBinding.func_74510_a((int)this.manualUseKeyCode, (boolean)false);
            return;
        }
        if (!(this.basicContextValid(player) && this.targetValid(player) && this.targetInsideRange(player))) {
            this.clearTarget();
            return;
        }
        long now = this.clock.getAsLong();
        this.expireHoldIfDue(now);
        if (!AutoBlockTiming.conditionsPass(this.checkLeftClick, this.checkRightClick, this.checkTookDamage, leftDown = this.attackIntent(now), rightDown = this.physicalDown(this.mc.field_71474_y.field_74313_G), resistanceTicks > 0)) {
            if (this.ownsBlock) {
                this.endBlock();
                this.cycle.exhaust();
            }
            return;
        }
        windowOpen = (resistanceTicks > 0 || !this.checkTookDamage) && AutoBlockTiming.ticksUntilVulnerable(resistanceTicks, player.field_70771_an) <= Math.max(0, Math.min(10, this.maximumHurtTicks));
        if (!windowOpen) {
            if (this.ownsBlock) {
                this.endBlock();
                this.cycle.exhaust();
            }
            if (resistanceTicks == 0 && this.cycle.state() == BlockCycle.State.WAITING) {
                this.cycle.exhaust();
            }
            return;
        }
        if (this.cycle.shouldStart(windowOpen, this.maximumHoldDuration)) {
            this.startBlock(player, now);
        }
    }

    private boolean syncSession() {
        WorldClient world = this.mc.field_71441_e;
        EntityPlayerSP player = this.mc.field_71439_g;
        if (world != this.observedWorld || player != this.observedPlayer) {
            this.clearAll();
            this.observedWorld = world;
            this.observedPlayer = player;
            this.previousResistanceTicks = player == null ? 0 : Math.max(0, player.field_70172_ad);
            this.previousHurtTicks = player == null ? 0 : Math.max(0, player.field_70737_aN);
            return false;
        }
        return true;
    }

    private boolean basicContextValid(EntityPlayerSP player) {
        return player != null && this.mc.field_71441_e != null && this.mc.field_71442_b != null && this.mc.field_71462_r == null && this.mc.field_71415_G && player.func_110143_aJ() > 0.0f && this.hasSword(player);
    }

    private boolean targetValid(EntityPlayerSP player) {
        if (this.target == null || this.target == player || this.target.field_70128_L || !this.target.func_70089_S() || this.mc.field_71441_e.func_73045_a(this.target.func_145782_y()) != this.target) {
            return false;
        }
        MovingObjectPosition hit = this.mc.field_71476_x;
        return hit != null && hit.field_72313_a == MovingObjectPosition.MovingObjectType.ENTITY && hit.field_72308_g == this.target;
    }

    private boolean hasSword(EntityPlayerSP player) {
        if (player == null) {
            return false;
        }
        ItemStack held = player.func_70694_bm();
        return held != null && AutoBlockTiming.isSword(held.func_77973_b());
    }

    private boolean targetInsideRange(EntityPlayerSP player) {
        AxisAlignedBB box = this.target.func_174813_aQ();
        return box != null && AutoBlockTiming.withinRange(player.field_70165_t, player.field_70163_u + (double)player.func_70047_e(), player.field_70161_v, box.field_72340_a, box.field_72338_b, box.field_72339_c, box.field_72336_d, box.field_72337_e, box.field_72334_f, Math.max(0.0f, this.range));
    }

    private boolean startBlock(EntityPlayerSP player, long now) {
        if (player.func_71039_bw()) {
            if (!this.isTimedMode()) {
                this.cycle.exhaust();
            }
            return false;
        }
        ItemStack sword = player.func_70694_bm();
        KeyBinding use = this.mc.field_71474_y.field_74313_G;
        this.ownedUseKeyCode = use.func_151463_i();
        if (this.ownedUseKeyCode == 0 || this.ownedUseKeyCode == this.mc.field_71474_y.field_74312_F.func_151463_i()) {
            if (!this.isTimedMode()) {
                this.cycle.exhaust();
            }
            return false;
        }
        KeyBinding.func_74510_a((int)this.ownedUseKeyCode, (boolean)true);
        this.ownsBlock = true;
        this.mc.field_71442_b.func_78769_a((EntityPlayer)player, (World)this.mc.field_71441_e, sword);
        if (player.func_71039_bw()) {
            if (!this.isTimedMode()) {
                this.cycle.begin(now);
            }
            return true;
        } else {
            this.releaseOwnedBlock();
            if (!this.isTimedMode()) {
                this.cycle.exhaust();
            }
            return false;
        }
    }

    private boolean expireHoldIfDue(long now) {
        if (!this.cycle.holdExpired(now, this.maximumHoldDuration)) {
            return false;
        }
        this.scheduleVanillaRelease();
        this.cycle.exhaust();
        return true;
    }

    private void clearTarget() {
        this.cancelTimedStart();
        this.timedGapPending = false;
        if (this.ownsBlock) {
            this.endBlock();
            this.cycle.exhaust();
        }
        this.timedCycle.reset();
        this.target = null;
        this.lastAttackNanos = Long.MIN_VALUE;
    }

    private void endBlock() {
        this.cancelTimedStart();
        this.timedGapPending = false;
        if (!this.ownsBlock || this.vanillaReleasePending) {
            return;
        }
        if (this.mc.field_71439_g == null || this.mc.field_71462_r != null || !this.mc.field_71415_G) {
            this.releaseOwnedBlock();
            return;
        }
        this.scheduleVanillaRelease();
    }

    private void scheduleVanillaRelease() {
        if (!this.ownsBlock || this.vanillaReleasePending) {
            return;
        }
        if (this.mc.field_71439_g == null || this.mc.field_71462_r != null || !this.mc.field_71415_G) {
            this.releaseOwnedBlock();
            return;
        }
        this.vanillaReleasePending = true;
        KeyBinding.func_74510_a((int)this.ownedUseKeyCode, (boolean)false);
    }

    private void finishVanillaRelease() {
        if (!this.vanillaReleasePending) {
            return;
        }
        EntityPlayerSP player = this.mc.field_71439_g;
        if (player != null && player.func_71039_bw()) {
            return;
        }
        KeyBinding.func_74510_a((int)this.ownedUseKeyCode, (boolean)this.physicalCodeDown(this.ownedUseKeyCode));
        this.vanillaReleasePending = false;
        this.ownsBlock = false;
        if (this.timedGapPending && "Timed".equals(this.activeMode)) {
            // The gap begins after vanilla actually released, not at timer expiry.
            this.timedCycle.beginGap(this.clock.getAsLong());
        }
        this.timedGapPending = false;
    }

    private void finishManualRelease() {
        if (!this.manualReleasePending) {
            return;
        }
        EntityPlayerSP player = this.mc.field_71439_g;
        if (player != null && player.func_71039_bw()) {
            return;
        }
        KeyBinding.func_74510_a((int)this.manualUseKeyCode, (boolean)this.physicalCodeDown(this.manualUseKeyCode));
        this.manualReleasePending = false;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void releaseOwnedBlock() {
        if (!this.ownsBlock) {
            return;
        }
        EntityPlayerSP player = this.mc.field_71439_g;
        try {
            if (player != null && this.mc.field_71442_b != null && player.func_71039_bw()) {
                this.mc.field_71442_b.func_78766_c((EntityPlayer)player);
            }
        }
        finally {
            try {
                KeyBinding.func_74510_a((int)this.ownedUseKeyCode, (boolean)this.physicalCodeDown(this.ownedUseKeyCode));
            }
            finally {
                this.vanillaReleasePending = false;
                this.ownsBlock = false;
            }
        }
    }

    private void clearAll() {
        this.cancelTimedStart();
        this.timedStartAttempted = false;
        this.timedGapPending = false;
        this.releaseOwnedBlock();
        if (this.manualReleasePending) {
            KeyBinding.func_74510_a((int)this.manualUseKeyCode, (boolean)this.physicalCodeDown(this.manualUseKeyCode));
            this.manualReleasePending = false;
        }
        this.clearTransientState();
    }

    private void clearTransientState() {
        this.cancelTimedStart();
        this.timedStartAttempted = false;
        this.timedGapPending = false;
        this.target = null;
        this.cycle.reset();
        this.timedCycle.reset();
        this.previousResistanceTicks = 0;
        this.previousHurtTicks = 0;
        this.lastAttackNanos = Long.MIN_VALUE;
        this.lastUnhurtArmNanos = Long.MIN_VALUE;
    }

    private boolean physicalDown(KeyBinding binding) {
        return binding != null && this.physicalCodeDown(binding.func_151463_i());
    }

    private boolean attackIntent(long now) {
        return this.physicalDown(this.mc.field_71474_y.field_74312_F) || this.lastAttackNanos != Long.MIN_VALUE && now >= this.lastAttackNanos && now - this.lastAttackNanos <= CLICK_GRACE_NANOS;
    }

    private boolean physicalCodeDown(int code) {
        if (code == 0) {
            return false;
        }
        try {
            return code < 0 ? Mouse.isButtonDown((int)(code + 100)) : Keyboard.isKeyDown((int)code);
        }
        catch (RuntimeException ignored) {
            return false;
        }
    }
}
