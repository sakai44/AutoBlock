package meowtils.extension;

import java.util.function.BooleanSupplier;
import wtf.tatp.meowtils.gui.component.ModuleComponent;
import wtf.tatp.meowtils.gui.component.subcomponents.SliderComponent;
import wtf.tatp.meowtils.gui.values.SliderValue;

/** Removes an inactive mode's slider row and blocks input at its old position. */
final class ConditionalSliderComponent extends SliderComponent {
    private final BooleanSupplier visible;

    ConditionalSliderComponent(SliderValue option, ModuleComponent component, int offset, BooleanSupplier visible) {
        super(option, component, offset);
        this.visible = visible;
    }

    private boolean isVisible() {
        return this.visible != null && this.visible.getAsBoolean();
    }

    @Override public void render() {
        if (this.isVisible()) super.render();
    }

    @Override public void updateComponent(int mouseX, int mouseY) {
        if (this.isVisible()) super.updateComponent(mouseX, mouseY);
    }

    @Override public boolean mouseClicked(int mouseX, int mouseY, int button) {
        return this.isVisible() && super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public int getHeight() {
        return this.isVisible() ? super.getHeight() : 0;
    }
}
