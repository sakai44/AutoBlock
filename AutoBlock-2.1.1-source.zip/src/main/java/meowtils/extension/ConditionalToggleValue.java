package meowtils.extension;

import java.util.function.BooleanSupplier;
import wtf.tatp.meowtils.gui.component.ModuleComponent;
import wtf.tatp.meowtils.gui.component.subcomponents.ToggleComponent;
import wtf.tatp.meowtils.gui.values.ToggleValue;

/** Keeps a saved toggle setting out of the layout when its mode is inactive. */
final class ConditionalToggleValue extends ToggleValue {
    private final BooleanSupplier visible;

    ConditionalToggleValue(String name, String fieldName, Object owner, BooleanSupplier visible) {
        super(name, fieldName, owner);
        this.visible = visible;
    }

    @Override
    public ToggleComponent createComponent(ModuleComponent component, int offset) {
        return new ConditionalToggleComponent(this, component, offset, this.visible);
    }
}
