package meowtils.extension;

import wtf.tatp.meowtils.extension.Extension;

/** Meowtils calls this entrypoint when the extension is loaded. */
public final class Main {
    private Main() {
    }

    public static void init() {
        Extension.registerModule(new AutoBlock());
    }
}
