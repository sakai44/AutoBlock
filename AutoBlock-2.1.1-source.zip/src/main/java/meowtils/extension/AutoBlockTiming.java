/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemSword
 */
package meowtils.extension;

import net.minecraft.item.ItemSword;

final class AutoBlockTiming {
    private AutoBlockTiming() {
    }

    static boolean conditionsPass(boolean checkLeft, boolean checkRight, boolean checkDamage, boolean leftDown, boolean rightDown, boolean recentlyDamaged) {
        return !(checkLeft && !leftDown || checkRight && !rightDown || checkDamage && !recentlyDamaged);
    }

    static boolean isSword(Object item) {
        return item instanceof ItemSword;
    }

    static boolean withinRange(double eyeX, double eyeY, double eyeZ, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, double range) {
        double dz;
        double dy;
        if (range < 0.0) {
            return false;
        }
        double dx = AutoBlockTiming.axisGap(eyeX, minX, maxX);
        return dx * dx + (dy = AutoBlockTiming.axisGap(eyeY, minY, maxY)) * dy + (dz = AutoBlockTiming.axisGap(eyeZ, minZ, maxZ)) * dz <= range * range;
    }

    private static double axisGap(double value, double min, double max) {
        return value < min ? min - value : (value > max ? value - max : 0.0);
    }

    static int ticksUntilVulnerable(int resistanceTicks, int maxResistanceTicks) {
        return Math.max(0, resistanceTicks - Math.max(0, maxResistanceTicks) / 2);
    }

    static int migrateHurtMillisToTicks(int millis) {
        return Math.max(0, Math.min(10, millis / 50));
    }

    static long unhurtAttackCycleNanos(int maxResistanceTicks) {
        int ticks = Math.max(1, maxResistanceTicks / 2);
        return (long)ticks * 50000000L;
    }
}

